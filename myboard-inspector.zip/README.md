# MyBoard Inspector

MyBoard Inspector is chrome extension for extract selector of specific website's contents.